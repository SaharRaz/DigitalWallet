export const SERVICE_NAME = 'user-service';
